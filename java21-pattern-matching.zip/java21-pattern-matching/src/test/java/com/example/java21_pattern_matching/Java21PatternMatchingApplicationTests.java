package com.example.java21_pattern_matching;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java21PatternMatchingApplicationTests {

	@Test
	void contextLoads() {
	}

}
